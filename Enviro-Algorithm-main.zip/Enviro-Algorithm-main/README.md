# Enviro-Algorithm
Ethan and Mandar are GOATS
